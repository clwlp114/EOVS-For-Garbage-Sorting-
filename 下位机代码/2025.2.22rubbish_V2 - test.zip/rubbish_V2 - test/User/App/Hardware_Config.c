#include "Hardware_Config.h"
#include "tim.h"
#include "can_bsp.h"
#include "dm4310_drv.h"
#include "Control_logic.h"
#include "maixcam.h"
#include "Belt.h"

Joint_Motor_t motor;
Clock task_clk;

void HardwareConfig(void) 
{
  FDCAN1_Config();
  FDCAN2_Config();
	Maixcam_Init();
	Motor_Init();
  joint_motor_init(&motor,1,POS_MODE);
		HAL_Delay(1000);
	for(int i=0;i<20;i++)
	{
		enable_motor_mode(&hfdcan1, motor.para.id, POS_MODE);//ʹ�ܵ��
		HAL_Delay(20);
	}
	
  HAL_TIM_Base_Start_IT(&htim14);
}