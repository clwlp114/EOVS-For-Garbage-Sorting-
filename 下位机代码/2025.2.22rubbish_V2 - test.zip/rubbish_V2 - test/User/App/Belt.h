#ifndef __ZHUANPAN_H__
#define __ZHUANPAN_H__

#include "main.h"

void Motor_Init();
void Motor_Control(int16_t speed);
void Motor_Control2(int16_t speed);
void red_back(void);


#endif 