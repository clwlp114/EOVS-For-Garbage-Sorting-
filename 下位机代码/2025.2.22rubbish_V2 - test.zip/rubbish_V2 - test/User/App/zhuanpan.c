#include "zhuanpan.h"
#include "maixcam.h"
#include "dm4310_drv.h"
#include "Hardware_Config.h"
#include "tim.h"
#include "usart.h"


uint16_t Zhuanpan_cnt = 0;

void Zhuanpan_Control(void)
{
	if(rubbish_flag == 0x00)			//�к�����
	{
		//pos_speed_ctrl(&hfdcan1,motor.para.id,6,5);
		
		if(Zhuanpan_State_Check() == 1)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,500); //ת��ת��ָ��λ�ã������
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit_DMA(&huart2, Usart2_Txbuff, 3);
			}
		}
		else if(Zhuanpan_State_Check() == 0)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500);//����ر�
		}
	}
	
	if(rubbish_flag == 0x01)				//�ɻ�������
	{
		//pos_speed_ctrl(&hfdcan1,motor.para.id,6,5);
		
		if(Zhuanpan_State_Check() == 1)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,500); //ת��ת��ָ��λ�ã������
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit_DMA(&huart2, Usart2_Txbuff, 3);
			}
		}
		else if(Zhuanpan_State_Check() == 0)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500);//����ر�
		}
	}
	
	if(rubbish_flag == 0x02)				//��������
	{
		//pos_speed_ctrl(&hfdcan1,motor.para.id,6,5);
		
		if(Zhuanpan_State_Check() == 1)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,500); //ת��ת��ָ��λ�ã������
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit_DMA(&huart2, Usart2_Txbuff, 3);
			}
		}
		else if(Zhuanpan_State_Check() == 0)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500);//����ر�
		}
	}
	
	if(rubbish_flag == 0x03)			//��������
	{
		//pos_speed_ctrl(&hfdcan1,motor.para.id,6,5);
		
		if(Zhuanpan_State_Check() == 1)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,500); //ת��ת��ָ��λ�ã������
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit_DMA(&huart2, Usart2_Txbuff, 3);
			}
		}
		else if(Zhuanpan_State_Check() == 0)
		{
//			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500);//����ر�
		}
	}
	
}

/**
  * @brief  ����1Ϊת��ת��ָ��λ�ã�0Ϊת��δת��ָ��λ��
  */
uint8_t Zhuanpan_State_Check()
{
	if(rubbish_servo_flag == 0x00)
	{
		if(motor.para.pos == 6)
		{
			return 1;
		}
		else if(motor.para.pos != 6)
		{
			return 0;
		}
	}
	
	
	if(rubbish_servo_flag == 0xFF)
	{
		return 0;
	}
}

