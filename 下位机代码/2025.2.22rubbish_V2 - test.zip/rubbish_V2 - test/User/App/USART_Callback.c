//
// Created by w1445 on 2024/11/26.
//

#include "USART_Callback.h"
#include "usart.h"
#include "maixcam.h"

/**
  * @brief  串口空闲中断回调函数
  */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size)
{
    if(huart == &huart2)
    {
			
        HAL_GPIO_TogglePin(GPIOE, GPIO_PIN_5);
				Maixcam_RxCallback();
    }


}
/**
  * @brief  串口接收中断回调函数
  */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{

}

void HAL_UART_ErrorCallback(UART_HandleTypeDef *huart)
{
    if(huart == &huart2)
    {
				Maixcam_Init();
//        hi91_data.eorror_check++;
    }


}
