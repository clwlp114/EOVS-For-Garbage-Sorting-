#ifndef __MAIXCAM_H__
#define __MAIXCAM_H__

#include "maixcam.h"
#include "main.h"

void Maixcam_Init(void);
void Maixcam_RxCallback();

extern uint8_t rubbish_flag;
extern uint8_t rubbish_servo_flag;
extern uint8_t Usart2_Txbuff[3];

#endif 