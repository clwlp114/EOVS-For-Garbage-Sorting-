#include "maixcam.h"
#include "main.h"
#include "usart.h"


uint8_t Usart2_Rxbuff[3] = {0};
uint8_t Usart2_Txbuff[3] = {0xAA,0x11,0xFF};			//��λ������ָ��������ͷ��ʼʶ��
uint8_t rubbish_flag = 0;
uint8_t rubbish_servo_flag = 0;
extern DMA_HandleTypeDef hdma_usart2_rx;


void Maixcam_Init(void)
{
    HAL_UARTEx_ReceiveToIdle_DMA(&huart2, Usart2_Rxbuff, 3); 
    __HAL_DMA_DISABLE_IT(&hdma_usart2_rx, DMA_IT_HT);                      
}

void Maixcam_RxCallback()
{
	if(Usart2_Rxbuff[0] == 0xAA && Usart2_Rxbuff[2] == 0xFF)
	{
		rubbish_flag = Usart2_Rxbuff[1];
		rubbish_servo_flag = Usart2_Rxbuff[1];
	}
	
	Maixcam_Init();
}

