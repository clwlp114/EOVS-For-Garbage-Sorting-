#include "Control_logic.h"
#include "tim.h"
#include "Hardware_Config.h"
#include "Check.h"
#include "dm4310_drv.h"
#include "zhuanpan.h"
#include "Belt.h"
#include "main.h"

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim == &htim14)
    {
			task_clk.tim14_clk++;
			Check_Status();
			Zhuanpan_Control();
			pos_speed_ctrl(&hfdcan1,motor.para.id,1,1);
			Motor_Control(10);
			Motor_Control2(10);
			red_back();
		}
}