#ifndef __HARDWARE_CONFIG_H__
#define __HARDWARE_CONFIG_H__

#include "Hardware_Config.h"
#include "dm4310_drv.h"

void HardwareConfig(void);

extern Joint_Motor_t motor;

#endif