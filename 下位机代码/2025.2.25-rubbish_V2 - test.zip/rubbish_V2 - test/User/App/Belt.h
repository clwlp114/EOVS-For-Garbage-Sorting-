#ifndef __ZHUANPAN_H__
#define __ZHUANPAN_H__

#include "main.h"

void Motor_Init();
void Motor_Control1(void);
void Motor_Control2(void);
void red_back(void);


#endif 