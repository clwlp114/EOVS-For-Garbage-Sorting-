//
// Created by w1445 on 2024/12/21.
//

#ifndef __CHECK_H__
#define __CHECK_H__

void Check_FPS(void);
void Check_Status(void);
void Online_check(void);

#endif //BALANCE_LEG_V2_CHECK_H
