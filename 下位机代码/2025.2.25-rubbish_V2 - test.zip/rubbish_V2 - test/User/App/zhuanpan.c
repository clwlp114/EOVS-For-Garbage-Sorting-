#include "zhuanpan.h"
#include "maixcam.h"
#include "dm4310_drv.h"
#include "Hardware_Config.h"
#include "tim.h"
#include "usart.h"


uint16_t Zhuanpan_cnt = 0;
float Target_pos = 0;
uint8_t x=3;

void ZP_PWM_Init()
{
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_4);
}

void Zhuanpan_Control(void)
{
	if(rubbish_flag == 0x00)			//�к�����
	{
		Target_pos = 1;
		pos_speed_ctrl(&hfdcan1,motor.para.id,Target_pos,5);
			x=Zhuanpan_State_Check(Target_pos);

		if(Zhuanpan_State_Check(Target_pos) == 1)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1000); //ת��ת��ָ��λ�ã������
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1000); 
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
 				HAL_UART_Transmit(&huart10, USART10_TX_BUF, 3,1000);
			}
		}
		else if(Zhuanpan_State_Check(Target_pos) == 0)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1500);//����ر�
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500); 
			Zhuanpan_cnt=0;
		}
	}
	
	if(rubbish_flag == 0x01)				//�ɻ�������
	{
		Target_pos = 4.2;
		pos_speed_ctrl(&hfdcan1,motor.para.id,Target_pos,5);
					x=Zhuanpan_State_Check(Target_pos);

		
		if(Zhuanpan_State_Check(Target_pos) == 1)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1000); //ת��ת��ָ��λ�ã������
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1000); 
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit(&huart10, USART10_TX_BUF, 3,1000);
			}
		}
		else if(Zhuanpan_State_Check(Target_pos) == 0)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1500);//����ر�
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500); 
						Zhuanpan_cnt=0;

		}
	}
	
	if(rubbish_flag == 0x02)				//��������
	{
		Target_pos = 2.6;
		pos_speed_ctrl(&hfdcan1,motor.para.id,Target_pos,5);
					x=Zhuanpan_State_Check(Target_pos);

		
		if(Zhuanpan_State_Check(Target_pos) == 1)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1000); //ת��ת��ָ��λ�ã������
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1000); 
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit(&huart10, USART10_TX_BUF, 3,1000);
			}
		}
		else if(Zhuanpan_State_Check(Target_pos) == 0)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1500);//����ر�
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500); 
						Zhuanpan_cnt=0;

		}
	}
	
	if(rubbish_flag == 0x03)			//��������
	{
		Target_pos = 5.8;
		pos_speed_ctrl(&hfdcan1,motor.para.id,Target_pos,5);
					x=Zhuanpan_State_Check(Target_pos);

		
		if(Zhuanpan_State_Check(Target_pos) == 1)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1000); //ת��ת��ָ��λ�ã������
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1000); 
			Zhuanpan_cnt ++;
			if(Zhuanpan_cnt>=2000)
			{
				rubbish_servo_flag = 0xFF;
				Zhuanpan_cnt = 0;
				HAL_UART_Transmit(&huart10, USART10_TX_BUF, 3,1000);
			}
		}
		else if(Zhuanpan_State_Check(Target_pos) == 0)
		{
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1500);//����ر�
			__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500); 
						Zhuanpan_cnt=0;

		}
	}
	
}

/**
  * @brief  ����1Ϊת��ת��ָ��λ�ã�0Ϊת��δת��ָ��λ��
  */
uint8_t Zhuanpan_State_Check(float pos)
{
	if(rubbish_servo_flag == 0x00 || rubbish_servo_flag == 0x01 || rubbish_servo_flag == 0x02 || rubbish_servo_flag == 0x03)
	{
		if((motor.para.pos<=pos+0.01)&&(motor.para.pos>=pos-0.01))
		{
			return 1;
		}
		else 
		{
			return 0;
		}
	}
	
	
	if(rubbish_servo_flag == 0xFF)
	{
		return 0;
	}
}

