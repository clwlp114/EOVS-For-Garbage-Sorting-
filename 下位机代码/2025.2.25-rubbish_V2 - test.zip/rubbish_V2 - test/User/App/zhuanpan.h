#ifndef __ZHUANPAN_H__
#define __ZHUANPAN_H__

#include "main.h"

void ZP_PWM_Init();
void Zhuanpan_Control(void);
uint8_t Zhuanpan_State_Check(float pos);

#endif 