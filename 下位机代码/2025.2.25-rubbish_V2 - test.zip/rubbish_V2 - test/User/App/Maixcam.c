#include "maixcam.h"
#include "main.h"
#include "usart.h"



uint8_t rubbish_flag = 0;
uint8_t rubbish_servo_flag = 0;


uint8_t USART10_RX_BUF[10];
uint8_t USART10_TX_BUF[3] = {0xAA,0x11,0xFF};//���յ�����ͷ��������Ϣ��2
uint16_t USART10_RX_STA = 0;
uint8_t USART10_NewData;
uint32_t uart_count = 0;

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	uart_count++;
	if(huart->Instance == USART10)
	{
		if((USART10_RX_STA & 0x8000) == 0)  //����δ���
		{
			if(USART10_NewData == 0xFF) //���յ���0x5A
			{
				USART10_RX_STA |= 0x8000;//��������ˣ���USART2_RX_STA��bit15��1
			}
			else
			{
				USART10_RX_BUF[USART10_RX_STA&0x7FFF] = USART10_NewData;//�����յ������ݷ�������
				USART10_RX_STA++;//���ݳ��ȼ�1
				if(USART10_RX_STA>127)
				{
					USART10_RX_STA = 0;
				}
			}
		}
		
		HAL_UART_Receive_IT(&huart10,(uint8_t*)&USART10_NewData,1);
	}
	if(USART10_RX_STA & 0x8000)
	{
		if(USART10_RX_BUF[0] == 0xAA)
		{
			rubbish_flag = USART10_RX_BUF[1];
			rubbish_servo_flag = USART10_RX_BUF[1];
//			Servo_flag = USART2_RX_BUF[1];
//			HAL_UART_Transmit(&huart2,(uint8_t*)&USART2_TX_BUF,3,0xFFFFFFFF);
		}
		USART10_RX_STA = 0;
	}
}


void Maixcam_Init(void)
{
//    HAL_UARTEx_ReceiveToIdle_DMA(&huart10, Usart10_Rxbuff, 3); 
//    __HAL_DMA_DISABLE_IT(&hdma_usart10_rx, DMA_IT_HT);  
		HAL_UART_Receive_IT(&huart10,(uint8_t*)&USART10_NewData,1);	
}

//void Maixcam_RxCallback()
//{
//	if(Usart2_Rxbuff[0] == 0xAA && Usart2_Rxbuff[2] == 0xFF)
//	{
//		rubbish_flag = Usart2_Rxbuff[1];
//		rubbish_servo_flag = Usart2_Rxbuff[1];
//	}
//	
//	Maixcam_Init();
//}

