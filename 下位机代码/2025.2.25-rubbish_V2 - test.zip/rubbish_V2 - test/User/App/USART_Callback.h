//
// Created by w1445 on 2024/11/26.
//

#ifndef __CALLBACK_H__
#define __CALLBACK_H__

#include "main.h"


#endif //BALANCE_LEG_V2_USART_CALLBACK_H
