#include "Control_logic.h"
#include "tim.h"
#include "Hardware_Config.h"
#include "Check.h"
#include "dm4310_drv.h"
#include "zhuanpan.h"
#include "Belt.h"
#include "main.h"
#include "usart.h"
#include "maixcam.h"
                             

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim == &htim14)
    {
			task_clk.tim14_clk++;
			Check_Status();
			Zhuanpan_Control();
//			pos_speed_ctrl(&hfdcan1,motor.para.id,1,1);
			Motor_Control1(10);
			Motor_Control2(10);
			red_back();
//			HAL_UART_Transmit(&huart10,  (uint8_t *)&USART10_TX_BUF, 3,1000);
//			HAL_UART_Transmit_DMA(&huart10,  (uint8_t *)&Usart10_Txbuff, 3);

		}
}