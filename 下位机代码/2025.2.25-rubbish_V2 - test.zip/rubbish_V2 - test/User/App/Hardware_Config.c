#include "Hardware_Config.h"
#include "tim.h"
#include "can_bsp.h"
#include "dm4310_drv.h"
#include "Control_logic.h"
#include "maixcam.h"
#include "Belt.h"
#include "zhuanpan.h"
#include "usart.h"


Joint_Motor_t motor;
Clock task_clk;

void HardwareConfig(void) 
{
  FDCAN1_Config();
  FDCAN2_Config();
	Maixcam_Init();
	Motor_Init();
	ZP_PWM_Init();
//	HAL_UART_Transmit(&huart10, USART10_TX_BUF, 3,1000);
  joint_motor_init (&motor,1,POS_MODE);
		HAL_Delay(1000);
	for(int i=0;i<20;i++)
	{
		enable_motor_mode(&hfdcan1, motor.para.id, POS_MODE);//ʹ�ܵ��
		HAL_Delay(20);
	}
	
//����
//	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_3,1500); //ת��ת��ָ��λ�ã������
//	__HAL_TIM_SetCompare(&htim2, TIM_CHANNEL_4,1500);
//			pos_speed_ctrl(&hfdcan1,motor.para.id,5.8,5);


  HAL_TIM_Base_Start_IT(&htim14);
}