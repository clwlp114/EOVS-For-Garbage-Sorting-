#ifndef __MAIXCAM_H__
#define __MAIXCAM_H__

#include "maixcam.h"
#include "main.h"

void Maixcam_Init(void);
void Maixcam_RxCallback();

extern uint8_t rubbish_flag;
extern uint8_t rubbish_servo_flag;
extern uint8_t USART10_TX_BUF[3];

#endif 