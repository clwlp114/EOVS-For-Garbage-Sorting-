#ifndef __CONTROL_LOGIC_H__
#define __CONTROL_LOGIC_H__

#include "main.h"

typedef struct {
    uint32_t tim14_clk;

}Clock;


extern Clock task_clk;


#endif